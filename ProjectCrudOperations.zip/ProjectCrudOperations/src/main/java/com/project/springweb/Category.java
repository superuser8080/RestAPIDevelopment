package com.project.springweb;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

@Entity
public class Category {

	@Id
	int cid;
	String name;
	@OneToMany(targetEntity = Product.class, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name ="cid")
	List<Product> product;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Category [cid=" + cid + ", name=" + name + ", product=" + product + "]";
	}

}
