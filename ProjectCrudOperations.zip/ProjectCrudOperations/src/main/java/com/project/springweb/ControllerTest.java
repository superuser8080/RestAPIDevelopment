package com.project.springweb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


public class ControllerTest {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@GetMapping("product/{pid}")
	public String getproduct(@PathVariable int pid) {
		
		Session session = sessionFactory.openSession();
		
		NativeQuery<Object []> nativeQuery = session.createSQLQuery("select product.product_id, product.product_name, product.product_price,category.category_name, category.category_id from category,product where product.category_id=category.category_id and product.product_id="+ pid);
		
		List<Object[]> list = nativeQuery.list();
		Object[] array = list.get(0);
		
		return Arrays.toString(array);

	}
	
	
}
